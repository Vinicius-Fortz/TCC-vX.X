<?php
	$nome_produto = $_POST['nome_produto'];
	$preco_produto = $_POST['preco_produto'];
	$descricao_produto = $_POST['descricao_produto'];
	$imagem_produto = $_POST['imagem_produto'];
	$dados = $_POST['id'];
	require("connectionbd.php");


	$sqlinsert = "UPDATE produto set nome_produto = '$nome_produto', preco_produto = '$preco_produto', descricao_produto = '$descricao_produto', imagem_produto = '$imagem_produto' WHERE id = '$dados'";
	
	

  
    
	
	mysqli_query($link, $sqlinsert) or die("Não foi possível editar o produto");

	echo "<script>alert('Dados editados com sucesso!')</script>
			<meta http-equiv='refresh'content=0.1;url='../listagem-produtos.php && ../editar.php'> ";

?>