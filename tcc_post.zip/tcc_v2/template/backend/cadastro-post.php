<?php

	require("connectionbd.php");

	$nome_postar = $_POST['nome_postar'];
	$data_postar = $_POST['data_postar'];
	$texto_postar = $_POST['texto_postar'];
	$imagem_postar = $_POST['imagem_postar'];

	$file = addslashes(file_get_contents($_FILES["imagem_postar"]["tmp_name"]));  

	$sqlinsert = "INSERT INTO postar(nome_postar, data_postar, texto_postar, imagem_postar) VALUES ('$nome_produto', '$data_produto', '$texto_produto', '$file')";

	mysqli_query($link, $sqlinsert) or die("Não foi possível cadastrar o produto");

	echo "<script>alert('Dados cadastrados com sucesso!')</script>
			<meta http-equiv='refresh'content=0.1;url='../fazer-post.php'> ";

?>
