<?php
	$nome_postar = $_POST['nome_postar'];
	$data_postar = $_POST['data_postar'];
	$texto_postar = $_POST['texto_postar'];
	$imagem_postar = $_POST['imagem_postar'];
	$identidade = $_POST['id'];
	
	require("connectionbd.php");

	$sqlinsert = "DELETE FROM postar WHERE id = '$identidade'";
	
	mysqli_query($link, $sqlinsert) or die("Não foi possível deletar o post");

	echo "<script>alert('Dados deletados com sucesso!')</script>
			<meta http-equiv='refresh'content=0.1;url='../listagem-produtos.php'> ";
?>