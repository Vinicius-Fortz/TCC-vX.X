<?php
	$host = "localhost";
	$usuario = "root";
	$senha = "";
	$bd = "riogrande_tcc";
	$link = mysqli_connect($host, $usuario, $senha, $bd);
?>