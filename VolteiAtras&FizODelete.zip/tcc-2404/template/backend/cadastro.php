<?php
	$nome_produto = $_POST['nome_produto'];
	$preco_produto = $_POST['preco_produto'];
	$descricao_produto = $_POST['descricao_produto'];
	$imagem_produto = $_POST['imagem_produto'];

	require("connectionbd.php");

	$sqlinsert = "INSERT INTO produto(nome_produto, preco_produto, descricao_produto, imagem_produto) VALUES ('$nome_produto', '$preco_produto', '$descricao_produto', '$imagem_produto')";

	mysqli_query($link, $sqlinsert) or die("Não foi possível cadastrar o produto");

	echo "<script>alert('Dados cadastrados com sucesso!')</script>
			<meta http-equiv='refresh'content=0.1;url='../cadastro.php'> ";

?>