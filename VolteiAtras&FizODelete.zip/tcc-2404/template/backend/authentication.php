<?php  
	session_start();

	require("connectionbd.php");
	
	$inputuser = $_POST['username'];
	$inputsenha = $_POST['password'];

	$sqluser = "SELECT username FROM user WHERE id = 1";
	$sqlsenha = "SELECT password FROM user WHERE id = 1";	

	$senha = mysqli_query($link, $sqluser) or die("Não foi possível checar os dados!");
	$user = mysqli_query($link, $sqlsenha) or die("Não foi possível checar os dados!");

	if ($inputuser == $user && $inputsenha == $senha) {
		echo "<script>alert('Login efetuado com sucesso!')</script>
			<meta http-equiv='refresh'content=0.1;url='../homepage-2.php'> ";
	} else {
		echo "<script>alert('Dados incorretos!')</script>
			  <meta http-equiv='refresh'content=0.1;url='../login.php'>";
	}


	/*if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
		echo "<script>alert('Login efetuado com sucesso!')</script>
			<meta http-equiv='refresh'content=0.1;url='../cadastro.php'> ";
	}

	if (isset($_SESSION['user']) && isset($_SESSION['password'])) {
		
		if ($_POST["username"] == $sqluser && $_POST["password"] == $sqlsenha) {
			
			$_SESSION["loggedin"] = true;
			echo "<script>alert('Login efetuado com sucesso!')</script>
			<meta http-equiv='refresh'content=0.1;url='../cadastro.php'> ";
		}
	}*/
?>