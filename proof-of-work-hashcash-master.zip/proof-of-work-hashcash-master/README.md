## MD5-Hashcash 演示

测试页面：[http://www.etherdream.com/hashcash/login.php](http://www.etherdream.com/hashcash/login.php)

讲解：[http://www.cnblogs.com/index-html/p/web-pow-research.html](http://www.cnblogs.com/index-html/p/web-pow-research.html)
