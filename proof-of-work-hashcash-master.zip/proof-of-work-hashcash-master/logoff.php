<?php
session_start();
session_destroy();
?>
已注销。<a href="login.php">重新登录</a>