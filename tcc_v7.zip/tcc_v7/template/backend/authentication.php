<?php
  require("connectionbd.php");

  if(empty($_POST['username']) || empty($_POST['password'])){
	  header('Location: ../index_loja.php');
	  exit();
  }

    $usuario = mysqli_real_escape_string($link, $_POST['username']);
	$senha = mysqli_real_escape_string($link, $_POST['password']);
	
	$query = "SELECT id, username FROM user WHERE username = '$usuario' AND password = md5('$senha')";
	
	$result = mysqli_query($link, $query);
 
	$row = mysqli_num_rows($result);
	
	if ($row == 1) {
		$_SESSION['username'] = $usuario;
		header('Location: ../menudashboard.php');
		exit();
	} else {
		header('Location: ../index_loja.php');
	}
	


?>